(function ($) {
  "use strict"; // Start of use strict
  function circleBlink () {
    var circles = $('.circles');
    $(circles[5]).fadeTo('slow', 1, function () {
      $(circles[4]).fadeTo('slow', 1, function () {
        $(circles[3]).fadeTo('slow', 1, function () {
         $(circles[2]).fadeTo('slow', 1, function () {
           $(circles[1]).fadeTo('slow', 1, function () {
              $(circles[0]).fadeTo('slow', 1, function() {
                circles.css('opacity', '0');
              });
             });
           });
          });
        });
      });  
  	};
  setInterval(circleBlink, 3500);
})(jQuery);
