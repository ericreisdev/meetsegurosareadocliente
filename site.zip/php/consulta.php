<?php
	ini_set('display_errors', 1);
	$username = "meetsegu_admin";
	$password = "meetpromoadmin";
	$database = "meetsegu_promo";
	
    $link = mysqli_connect("localhost", $username, $password, $database);
	 
	$input = mysqli_real_escape_string($link, $_POST['input']);
	
	$query = "SELECT `code` FROM `promo` WHERE `id` = '$input'";
	
	$result = mysqli_query($link, $query);
	
	if (!$result) {
        $message  = 'Invalid query: ' . mysql_error() . "\n";
        $message .= 'Whole query: ' . $query;
        die($message);
        echo 'error';
    }
    	
    while ($row = mysqli_fetch_assoc($result)) {
        echo $row['code'];
    }
    mysqli_free_result($result);
?>